<div class="poem-container">
    <h1 class="poem-title">Pequeno</h1>

    <div class="poem-stanza">
        <p class="poem-line">Eu sonho tão grande que deixo as pessoas desconfortáveis.</p>
    </div>

    <div class="poem-stanza">
        <p class="poem-line">Eu sou um deus ancião e imponente, esquecido por muitos e só discutido por pouquíssimos acadêmicos.</p>
        <p class="poem-line">Então, se eu não acreditar em mim, ninguém mais vai.</p>
    </div>

    <div class="poem-stanza">
        <p class="poem-line">Eu me sinto pequeno, mas até as estrelas são, de certa distância.</p>
    </div>

    <div class="poem-stanza">
        <p class="poem-line">Eu sou uma lagarta, pronta para virar uma borboleta, mas em um covil de cobras.</p>
    </div>

    <div class="poem-stanza">
        <p class="poem-line">Eu vivo em um mundo de gigantes,</p>
        <p class="poem-line">Então eu apenas rezo para que não me matem pelo pecado de ser pequeno.</p>
    </div>

    <p class="poem-author">- Alana Serra</p>
</div>

<style>
    /* Contêiner do poema */
    .poem-container {
        max-width: 600px; /* Limita a largura para evitar linhas muito longas */
        margin: 20px;
        padding: 30px;
        background-color: #fff; /* Fundo branco para destacar o poema */
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Sombra suave para profundidade */
    }

    /* Título do poema */
    .poem-title {
        font-size: 2.5em; /* Tamanho maior para o título */
        font-weight: bold;
        text-align: center;
        color: #2c3e50; /* Cor do título */
        margin-bottom: 20px;
    }

    /* Estilo para cada estrofe do poema */
    .poem-stanza {
        margin-bottom: 15px;
        padding-left: 20px;
        text-align: justify;
        text-indent: -20px; /* Para adicionar um pequeno recuo à primeira linha */
    }

    /* Estilo para versos individuais */
    .poem-line {
        margin-bottom: 10px;
        font-style: italic; /* Estilo em itálico para os versos */
        color: #7f8c8d; /* Cor mais suave para os versos */
    }

    /* Citando o autor */
    .poem-author {
        font-size: 1.2em;
        text-align: right;
        color: #34495e;
        font-style: italic;
        margin-top: 20px;
    }
</style>
