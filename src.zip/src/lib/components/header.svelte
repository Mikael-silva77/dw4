<header class="navbar navbar-expand-lg bg-body-tertiary">
    <button class="navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#mySideBar" aria-label="toggleSidebar">
      <i class="bi bi-list"></i>
    </button>
    <a class="navbar-brand" href="/">FrameWorks</a>
    <button class="navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#navbarText" aria-label="toggleNavbar">
      <i class="bi bi-three-dots-vertical"></i>
    </button>
    <div class="offcanvas offcanvas-end" tabindex="-1" id="navbarText">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav me-auto">
          <li class="nav-item"><a class="nav-link active" href="/01">Cap 01</a></li>
          <li class="nav-item"><a class="nav-link active" href="/02">Cap 02</a></li>
        </ul>
      </div>
    </div>
  </header>