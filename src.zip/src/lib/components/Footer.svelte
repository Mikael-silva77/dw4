<footer class="d-flex justify-content-between align-items-center py-1 mt-auto border-top">
    <p class="mb-0 text-body-secondary">&copy; 2024 Company, Inc</p>
   
    <a href="/"><img src="/favicon.png" alt="logo" style="height: 2em" /></a>
   
    <ul class="nav">
      <li class="nav-item"><a href="https://facebook.com" target="_blank" class="nav-link px-2 text-body-secondary" aria-label="facebook"><i class="bi bi-facebook"></i></a></li>
      <li class="nav-item"><a href="https://whatsapp.com" target="_blank" class="nav-link px-2 text-body-secondary" aria-label="whatsapp"><i class="bi bi-whatsapp"></i></a></li>
      <li class="nav-item"><a href="https://twitter.com" target="_blank" class="nav-link px-2 text-body-secondary" aria-label="twitter"><i class="bi bi-twitter"></i></a></li>
    </ul>
  </footer>