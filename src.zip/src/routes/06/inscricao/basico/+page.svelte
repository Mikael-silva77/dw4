<script>
   export let form = {};
 </script>
 
 <h2>Plano Bit (Básico)</h2>
 <p>Pagamento aprovado. Bem-vindo(a) ao Plano Bit!</p>