<script>

   let src = 'INST_SemPatch_SITE_1500.jpg';
</script>

<img src = 'INST_SemPatch_SITE_1500.jpg'>