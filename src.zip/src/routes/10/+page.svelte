<div class="container">
    <div class="list-group">
        <a href="/10/cotacao" class="list-group-item list-group-item-action">Cotação</a>
    </div>
</div>
