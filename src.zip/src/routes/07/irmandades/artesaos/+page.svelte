<h1>Bem-vindo à Guilda dos Artesãos!</h1>
<p>Sua habilidade manual será valorizada por todo o reino.</p>