<h1>Bem-vindo ao Círculo dos Magos!</h1>
<p>O conhecimento arcano está ao seu alcance. Use-o com sabedoria.</p>