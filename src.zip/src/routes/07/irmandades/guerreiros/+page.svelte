<h1>Bem-vindo à Ordem dos Guerreiros!</h1>
<p>Você foi aceito como guerreiro. Prepare-se para a batalha!</p>